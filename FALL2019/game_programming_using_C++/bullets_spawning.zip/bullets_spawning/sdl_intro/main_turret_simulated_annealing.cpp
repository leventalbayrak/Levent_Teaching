﻿#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "SDL2-2.0.10/include/SDL.h"

#pragma comment(lib,"SDL2-2.0.10/lib/x86/SDL2.lib")
#pragma comment(lib,"SDL2-2.0.10/lib/x86/SDL2main.lib")
#pragma comment(linker,"/subsystem:console")

#pragma warning(disable:4996)

#define ZERO {0}

SDL_Renderer* renderer = NULL;

struct Bullet
{
	float x, y;
	float dx, dy;//unit vector
	float speed;
};

void type0()
{
	SDL_Init(SDL_INIT_VIDEO);

	srand(time(0));

	int screen_width = 1280;
	int screen_height = 800;
	SDL_Window* window = SDL_CreateWindow("SIMULATED ANNEALING", 100, 100, screen_width, screen_height, SDL_WINDOW_SHOWN);
	renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

	const int maxnbullets = 1000;
	static Bullet bullets[maxnbullets] = ZERO;
	static int active[maxnbullets] = ZERO;

	float px = screen_width / 2;
	float py = screen_height / 2;

	for (;;)
	{
		/*
		consume events
		*/
		SDL_Event event;
		while (SDL_PollEvent(&event))
		{
			if (event.type == SDL_QUIT)
			{
				printf("GOODBYE\n");
				exit(0);
			}
		}

		/*
		game code here
		*/
		int mx, my;
		unsigned int mouse_state = SDL_GetMouseState(&mx, &my);

		int spawn_bullet = 0;
		if (mouse_state & SDL_BUTTON(SDL_BUTTON_LEFT))
		{
			spawn_bullet = 1;
		}


		if (spawn_bullet)
		{
			//search for an inactive bullet, activate it, break
			for (int i = 0; i < maxnbullets; ++i)
			{
				if (active[i] == 0)
				{
					active[i] = 1;
					
					float dx = mx - px;
					float dy = my - py;
					float mag = sqrt(dx*dx + dy * dy);
					if (mag != 0.0f)
					{
						dx /= mag;
						dy /= mag;
					}

					bullets[i].dx = dx;
					bullets[i].dy = dy;
					bullets[i].speed = 0.1f + 0.1f*rand() / RAND_MAX;
					bullets[i].x = px;
					bullets[i].y = py;

					break;
				}
			}
		}

		for (int i = 0; i < maxnbullets; ++i)
		{
			if (active[i] == 0) continue;
			if (bullets[i].x < 0 || bullets[i].x > screen_width ||
				bullets[i].y < 0 || bullets[i].y > screen_height
				)
			{
				//kill
				active[i] = 0;
			}
		}

		for (int i = 0; i < maxnbullets; ++i)
		{
			if (active[i] == 0) continue;
			bullets[i].x += bullets[i].dx * bullets[i].speed;
			bullets[i].y += bullets[i].dy * bullets[i].speed;
		}


		/*
		draw
		clear screen once
		*/
		SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
		SDL_RenderClear(renderer);


		SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
		for (int i = 0; i < maxnbullets; ++i)
		{
			if (active[i] == 0) continue;
			SDL_Rect rect = { bullets[i].x, bullets[i].y, 8,8 };
			SDL_RenderFillRect(renderer, &rect);
		}


		/*
		once per frame!
		*/
		SDL_RenderPresent(renderer);

	}
}


typedef unsigned char uchar;

namespace Bitarray
{
	inline int get_Bit(const unsigned char* bitarray, int index)
	{
		int byte_index = index >> 3;
		int bit = index & 7;
		return bitarray[byte_index] & (1 << bit);
	}

	inline void set_Bit(unsigned char* bitarray, int index)
	{
		int byte_index = index >> 3;
		int bit = index & 7;
		bitarray[byte_index] |= (1 << bit);
	}

	inline void reset_Bit(unsigned char* bitarray, int index)
	{
		int byte_index = index >> 3;
		int bit = index & 7;
		bitarray[byte_index] &= ~(1 << bit);
	}

	inline void flip_Bit(unsigned char* bitarray, int index)
	{
		int byte_index = index >> 3;
		int bit = index & 7;
		bitarray[byte_index] ^= (1 << bit);
	}
}

void type1()
{
	SDL_Init(SDL_INIT_VIDEO);

	srand(time(0));

	int screen_width = 1280;
	int screen_height = 800;
	SDL_Window* window = SDL_CreateWindow("SIMULATED ANNEALING", 100, 100, screen_width, screen_height, SDL_WINDOW_SHOWN);
	renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

	const int maxnbullets = 4096;
	static Bullet bullets[maxnbullets] = ZERO;
	static uchar active[maxnbullets>>3] = ZERO;

	float px = screen_width / 2;
	float py = screen_height / 2;

	for (;;)
	{
		/*
		consume events
		*/
		SDL_Event event;
		while (SDL_PollEvent(&event))
		{
			if (event.type == SDL_QUIT)
			{
				printf("GOODBYE\n");
				exit(0);
			}
		}

		/*
		game code here
		*/
		int mx, my;
		unsigned int mouse_state = SDL_GetMouseState(&mx, &my);

		int spawn_bullet = 0;
		if (mouse_state & SDL_BUTTON(SDL_BUTTON_LEFT))
		{
			spawn_bullet = 1;
		}


		if (spawn_bullet)
		{
			//search for an inactive bullet, activate it, break
			for (int i = 0; i < maxnbullets; ++i)
			{
				if (Bitarray::get_Bit(active, i) == 0)
				{
					Bitarray::set_Bit(active, i);

					float dx = mx - px;
					float dy = my - py;
					float mag = sqrt(dx*dx + dy * dy);
					if (mag != 0.0f)
					{
						dx /= mag;
						dy /= mag;
					}

					bullets[i].dx = dx;
					bullets[i].dy = dy;
					bullets[i].speed = 0.1f + 0.1f*rand() / RAND_MAX;
					bullets[i].x = px;
					bullets[i].y = py;

					break;
				}
			}
		}

		for (int i = 0; i < maxnbullets; ++i)
		{
			if (Bitarray::get_Bit(active, i) == 0) continue;

			if (bullets[i].x < 0 || bullets[i].x > screen_width ||
				bullets[i].y < 0 || bullets[i].y > screen_height
				)
			{
				//kill
				Bitarray::reset_Bit(active, i);
			}
		}

		for (int i = 0; i < maxnbullets; ++i)
		{
			if (Bitarray::get_Bit(active, i) == 0) continue;

			bullets[i].x += bullets[i].dx * bullets[i].speed;
			bullets[i].y += bullets[i].dy * bullets[i].speed;
		}


		/*
		draw
		clear screen once
		*/
		SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
		SDL_RenderClear(renderer);


		SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
		for (int i = 0; i < maxnbullets; ++i)
		{
			if (Bitarray::get_Bit(active, i) == 0) continue;

			SDL_Rect rect = { bullets[i].x, bullets[i].y, 8,8 };
			SDL_RenderFillRect(renderer, &rect);
		}

		int count = 0;
		for (int i = 0; i < maxnbullets; ++i)
		{
			if (Bitarray::get_Bit(active, i)) count++;
		}
		printf("%d\n", count);
		/*
		once per frame!
		*/
		SDL_RenderPresent(renderer);

	}
}
int main(int argc, char** argv)
{
	type1();

	return 0;
}
﻿#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "SDL2-2.0.10/include/SDL.h"

#pragma comment(lib,"SDL2-2.0.10/lib/x86/SDL2.lib")
#pragma comment(lib,"SDL2-2.0.10/lib/x86/SDL2main.lib")
#pragma comment(linker,"/subsystem:console")

#pragma warning(disable:4996)

SDL_Renderer* renderer = NULL;

struct Square
{
	float x, y;
};
int square_size = 200;

int collide(Square* a, Square* b, int size)
{
	if (a->x + size < b->x) return 0;
	if (a->x > b->x + size) return 0;
	if (a->y + size < b->y) return 0;
	if (a->y > b->y + size) return 0;
	return 1;
}

int main(int argc, char** argv)
{
	SDL_Init(SDL_INIT_VIDEO);

	srand(time(0));

	int screen_width = 1280;
	int screen_height = 800;
	SDL_Window* window = SDL_CreateWindow("SIMULATED ANNEALING", 100, 100, screen_width, screen_height, SDL_WINDOW_SHOWN);
	renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);

	const int max_n_squares = 10;
	static Square current[max_n_squares];
	static Square best[max_n_squares];
	float best_score = -max_n_squares*max_n_squares;
	float temperature = 1.0;
	float decay = 0.9995;

	int nsquares_changed = 2;
	float movement_amount = 32.0f;

	for (int i = 0; i < max_n_squares; ++i)
	{
		current[i].x = rand() % (screen_width - square_size);
		current[i].y = rand() % (screen_height - square_size);

		best[i] = current[i];
	}

	int train = 1;

	for (;;)
	{
		/*
		consume events
		*/
		SDL_Event event;
		while (SDL_PollEvent(&event))
		{
			if (event.type == SDL_QUIT)
			{
				printf("GOODBYE\n");
				exit(0);
			}
		}

		/*
		game code here
		*/

		if (train)
		{
			//modify current solution
			for (int i = 0; i < nsquares_changed; ++i)
			{
				int k = rand() % max_n_squares;
				current[k].x += movement_amount * (1.0f - 2.0f*rand() / RAND_MAX);
				current[k].y += movement_amount * (1.0f - 2.0f*rand() / RAND_MAX);
			}

			//measure fitness of solution
			int ncollisions = 0;
			for (int i = 0; i < max_n_squares; ++i)
			{
				for (int j = i + 1; j < max_n_squares; ++j)
				{
					if (collide(&current[i], &current[j], square_size) == 1) ncollisions++;
				}
			}

			int noutofbounds = 0;
			for (int i = 0; i < max_n_squares; ++i)
			{
				if (current[i].x < 0 || (current[i].x + square_size > screen_width)) noutofbounds++;
				if (current[i].y < 0 || (current[i].y + square_size > screen_height)) noutofbounds++;
			}

			//decide if a swap between current and best should be made
			float current_score = -ncollisions - noutofbounds*noutofbounds;
			if (current_score > best_score)
			{
				best_score = current_score;
				for (int i = 0; i < max_n_squares; ++i) best[i] = current[i];
			}
			else
			{
				float p = (float)rand() / RAND_MAX;
				if (p <= exp((current_score - best_score) / temperature))
				{
					best_score = current_score;
					for (int i = 0; i < max_n_squares; ++i) best[i] = current[i];
				}
				else
				{
					current_score = best_score;
					for (int i = 0; i < max_n_squares; ++i) current[i] = best[i];
				}
			}

			temperature *= decay;
			printf("%d %.4f\n",ncollisions, temperature);

			if (temperature < 0.0001 || ncollisions == 0)
			{
				train = 0;
			}
		}

		/*
		draw
		clear screen once
		*/
		SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
		SDL_RenderClear(renderer);

		SDL_SetRenderDrawColor(renderer, 0, 255, 0, 255);
		for (int i = 0; i < max_n_squares; ++i)
		{
			SDL_Rect rect = { current[i].x, current[i].y, square_size, square_size };
			SDL_RenderFillRect(renderer, &rect);
		}
		
	
		/*
		once per frame!
		*/
		SDL_RenderPresent(renderer);

	}








	return 0;
}